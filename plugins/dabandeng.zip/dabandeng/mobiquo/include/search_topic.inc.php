<?php

defined('IN_MOBIQUO') or exit;

include('./include/search.inc.php');

?>