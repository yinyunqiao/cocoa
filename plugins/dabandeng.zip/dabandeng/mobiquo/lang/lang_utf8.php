<?php

global $dabandeng_lang;

$dabandeng_lang = array(
    'dabandeng_latest_picture'      => '最新图片',
    'dabandeng_forum_statistics'    => '论坛统计',
    'dabandeng_latest_topic'        => '最新主题',
    'dabandeng_latest_reply'        => '最新回复',
    'dabandeng_hot'                 => '热门主题',
    'dabandeng_latest_recommend'    => '推荐主题',
    'dabandeng_latest_digest'       => '最新精华',
    'dabandeng_latest_stick'        => '最新置顶',
    'dabandeng_most_reply'          => '最多回复',
    'dabandeng_most_view'           => '最多浏览',
    'dabandeng_most_view_today'     => '今日最多浏览',
    'dabandeng_most_view_week'      => '本周最多浏览',
    'dabandeng_most_view_month'     => '本月最多浏览',
);

?>